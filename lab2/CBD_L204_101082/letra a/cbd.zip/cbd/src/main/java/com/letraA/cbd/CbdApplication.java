package com.letraA.cbd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CbdApplication {

	public static void main(String[] args) {
		SpringApplication.run(CbdApplication.class, args);
	}

}
