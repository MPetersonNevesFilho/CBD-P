package com.letraA.cbd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CbdApplicationTests {

	@Test
	void contextLoads() {
	}

}
